-- Add to DuelRecord.toc: ## SavedVariablesPerCharacter: DuelRecordDBPC
-- Create the main frame (referred to as "Frame A")
local FrameA = CreateFrame("Frame", "DuelRecordFrameA", UIParent)
FrameA:SetSize(1090, 450)
FrameA:SetPoint("CENTER") -- Centers the frame on the screen; adjust as needed
FrameA:SetBackdrop({
    bgFile = "Interface\\ChatFrame\\ChatFrameBackground", -- Solid black texture
    edgeFile = nil, -- No border for simplicity
    tile = false,
    tileSize = 0,
    edgeSize = 0,
})
FrameA:SetBackdropColor(0, 0, 0, 0.5) -- Black color with 50% translucency (alpha = 0.5)
FrameA:SetMovable(true) -- Allow dragging the frame
FrameA:EnableMouse(true) -- Enable mouse interactions
FrameA:RegisterForDrag("LeftButton") -- Drag with left mouse button
FrameA:SetScript("OnDragStart", FrameA.StartMoving)
FrameA:SetScript("OnDragStop", FrameA.StopMovingOrSizing)
FrameA:Hide() -- Start hidden
tinsert(UISpecialFrames, "DuelRecordFrameA")
-- Create the title text at the top center of Frame A
local titleText = FrameA:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
titleText:SetPoint("TOP", FrameA, "TOP", 0, -7) -- Positioned at the top center, 10 pixels down to avoid clipping
titleText:SetTextColor(144/255, 224/255, 247/255, 1) -- Arctic Blue
titleText:SetText(UnitName("player") .. "'s Duel Record")
titleText:SetJustifyH("CENTER")
-- Create the record text centered below the title
local recordText = FrameA:CreateFontString(nil, "OVERLAY", "GameFontNormal")
recordText:SetTextColor(1, 1, 1, 1) -- White text (for any non-colored parts)
recordText:SetJustifyH("LEFT")
-- Create the "Total - " text to the left of the record text
local totalLabel = FrameA:CreateFontString(nil, "OVERLAY", "GameFontNormal")
totalLabel:SetTextColor(1, 1, 1, 1) -- White text
totalLabel:SetText("Total - ")
totalLabel:SetJustifyH("LEFT")
-- Create the current streak text under the total win/loss line
local currentStreakText = FrameA:CreateFontString(nil, "OVERLAY", "GameFontNormal")
currentStreakText:SetPoint("TOP", FrameA, "TOP", 0, -48)
currentStreakText:SetTextColor(1, 1, 1, 1)
currentStreakText:SetJustifyH("CENTER")
-- Create the best streak text below "Current Streak - "
local bestStreakText = FrameA:CreateFontString(nil, "OVERLAY", "GameFontNormal")
bestStreakText:SetPoint("TOP", FrameA, "TOP", 0, -68)
bestStreakText:SetTextColor(1, 1, 1, 1)
bestStreakText:SetJustifyH("CENTER")
-- Create the scroll frame
local scrollFrame = CreateFrame("ScrollFrame", "DuelRecordScrollFrame", FrameA, "UIPanelScrollFrameTemplate")
scrollFrame:SetPoint("TOPLEFT", FrameA, "TOPLEFT", 0, -120)
scrollFrame:SetPoint("BOTTOMRIGHT", FrameA, "BOTTOMRIGHT", -160, 50)
-- Create the content frame for scrolling
local content = CreateFrame("Frame", nil, scrollFrame)
content:SetWidth(scrollFrame:GetWidth())
content:SetHeight(280)
scrollFrame:SetScrollChild(content)
-- Get the scrollbar
local scrollBar = _G["DuelRecordScrollFrameScrollBar"]
-- Move the vertical scrollbar 30 pixels to the left
scrollBar:ClearAllPoints()
scrollBar:SetPoint("TOPLEFT", scrollFrame, "TOPRIGHT", -13 - 15, -15)
scrollBar:SetPoint("BOTTOMLEFT", scrollFrame, "BOTTOMRIGHT", -13 - 15, 15)
-- Move the scrollbar textures 30 pixels to the left
local scrollTop = _G["DuelRecordScrollFrameTop"]
local scrollBottom = _G["DuelRecordScrollFrameBottom"]
local scrollMiddle = _G["DuelRecordScrollFrameMiddle"]
if scrollTop then
    scrollTop:ClearAllPoints()
    scrollTop:SetPoint("TOPLEFT", scrollFrame, "TOPRIGHT", -10 - 15, 5)
end
if scrollBottom then
    scrollBottom:ClearAllPoints()
    scrollBottom:SetPoint("BOTTOMLEFT", scrollFrame, "BOTTOMRIGHT", -10 - 15, -2)
end
if scrollMiddle then
    scrollMiddle:ClearAllPoints()
    scrollMiddle:SetPoint("TOP", scrollTop, "BOTTOM")
    scrollMiddle:SetPoint("BOTTOM", scrollBottom, "TOP")
end
-- Create the secondary frame (referred to as "Frame B"), parented to content
local FrameB = CreateFrame("Frame", "DuelRecordFrameB", content)
FrameB:SetSize(200, 280)
FrameB:SetPoint("TOPLEFT", content, "TOPLEFT", 0, 0)
FrameB:SetBackdrop({
    bgFile = "Interface\\ChatFrame\\ChatFrameBackground", -- Solid black texture
    edgeFile = nil, -- No border for simplicity
    tile = false,
    tileSize = 0,
    edgeSize = 0,
})
FrameB:SetBackdropColor(0, 0, 0, 0.5) -- Black color with 50% translucency (alpha = 0.5) for slightly darker appearance
-- Create the new frame on top of Frame B (referred to as "Frame B1"), parented to Frame A
local FrameB1 = CreateFrame("Frame", "DuelRecordFrameB1", FrameA)
FrameB1:SetSize(200, 30)
FrameB1:SetPoint("TOPLEFT", FrameA, "TOPLEFT", 0, -90)
FrameB1:SetBackdrop({
    bgFile = "Interface\\ChatFrame\\ChatFrameBackground", -- Solid black texture
    edgeFile = nil, -- No border for simplicity
    tile = false,
    tileSize = 0,
    edgeSize = 0,
})
FrameB1:SetBackdropColor(0, 0, 0, 0.5) -- Same as Frame C: Black with 50% translucency
-- Create the tertiary frame (referred to as "Frame C"), parented to content
local FrameC = CreateFrame("Frame", "DuelRecordFrameC", content)
FrameC:SetSize(690, 280)
FrameC:SetPoint("TOPLEFT", content, "TOPLEFT", 200, 0)
FrameC:SetBackdrop({
    bgFile = "Interface\\ChatFrame\\ChatFrameBackground", -- Solid black texture
    edgeFile = nil, -- No border for simplicity
    tile = false,
    tileSize = 0,
    edgeSize = 0,
})
FrameC:SetBackdropColor(0, 0, 0, 0.5) -- Same as Frame A: Black with 50% translucency
-- Create the new frame (referred to as "Frame C1"), parented to Frame A, anchored above the scroll area
local FrameC1 = CreateFrame("Frame", "DuelRecordFrameC1", FrameA)
FrameC1:SetSize(690, 30)
FrameC1:SetPoint("TOPLEFT", FrameA, "TOPLEFT", 200, -90)
FrameC1:SetBackdrop({
    bgFile = "Interface\\ChatFrame\\ChatFrameBackground", -- Solid black texture
    edgeFile = nil, -- No border for simplicity
    tile = false,
    tileSize = 0,
    edgeSize = 0,
})
FrameC1:SetBackdropColor(0, 0, 0, 0.5) -- Same as Frame C: Black with 50% translucency
local currentSort = "name"
local sortAscending = true
local classes = {"Death Knight", "Druid", "Hunter", "Mage", "Paladin", "Priest", "Rogue", "Shaman", "Warlock", "Warrior", "Unknown"}
local selectedClasses = {}
for _, class in ipairs(classes) do
    selectedClasses[class] = true
end
local specialStreaks = {
    [5] = true,
    [10] = true,
    [15] = true,
    [20] = true,
    [25] = true,
    [30] = true,
    [35] = true,
    [40] = true,
    [45] = true,
    [50] = true,
    [75] = true,
    [100] = true,
    [150] = true,
    [200] = true,
    [300] = true,
    [500] = true,
    [1000] = true,
}
-- Function to update the record text
local function UpdateRecordText()
    local wins = 0
    local losses = 0
    for name, opp in pairs(DuelRecordDBPC.opponents) do
        if selectedClasses[opp.class or "Unknown"] then
            wins = wins + (opp.wins or 0)
            losses = losses + (opp.losses or 0)
        end
    end
    local total = wins + losses
    local percent = total > 0 and string.format("%.2f", (wins / total) * 100) or "0.00"
    local num_percent = total > 0 and (wins / total) * 100 or 0
    local red = math.floor(255 * (1 - num_percent / 100) + 0.5)
    local green = math.floor(255 * (num_percent / 100) + 0.5)
    local blue = 0
    local color_code = string.format("|cFF%02X%02X%02X", red, green, blue)
    local winStr = "|cFF00FF00" .. wins .. "|r" -- Green for wins
    local lossStr = "|cFFFF0000" .. losses .. "|r" -- Red for losses
    local percentStr = color_code .. percent .. "%|r" -- Gradient for percent
    recordText:SetText(winStr .. "-" .. lossStr .. " (" .. percentStr .. ")")
    local totalWidth = totalLabel:GetStringWidth() + recordText:GetStringWidth()
    totalLabel:ClearAllPoints()
    totalLabel:SetPoint("TOPLEFT", FrameA, "TOP", -totalWidth / 2, -28)
    recordText:ClearAllPoints()
    recordText:SetPoint("TOPLEFT", totalLabel, "TOPRIGHT", 0, 0)
end
-- Function to get combined history for selected classes
local function GetSelectedClassesHistory()
    local hist = {}
    for name, opp in pairs(DuelRecordDBPC.opponents) do
        if selectedClasses[opp.class or "Unknown"] then
            for _, rec in ipairs(opp.history or {}) do
                table.insert(hist, {time = rec.time, outcome = rec.outcome})
            end
        end
    end
    table.sort(hist, function(a, b) return a.time < b.time end)
    return hist
end
-- Function to update the current streak text
local function UpdateCurrentStreakText()
    local streak = 0
    local text = "Current Streak"
    local hist = GetSelectedClassesHistory()
    local j = #hist
    while j > 0 do
        local out = hist[j].outcome
        if out == "win" or out == "opponent_fled" then
            streak = streak + 1
            j = j - 1
        else
            break
        end
    end
    currentStreakText:SetText(text .. " - |cFF00FF00" .. streak .. "|r")
end
-- Function to update the best streak text
local function UpdateBestStreakText()
    local bestStreak = 0
    local text = "Best Streak"
    local hist = GetSelectedClassesHistory()
    local current = 0
    for _, rec in ipairs(hist) do
        if rec.outcome == "win" or rec.outcome == "opponent_fled" then
            current = current + 1
            bestStreak = math.max(bestStreak, current)
        else
            current = 0
        end
    end
    bestStreakText:SetText(text .. " - |cFF00FF00" .. bestStreak .. "|r")
end
-- Helper function to escape Lua pattern magic characters
local function escapePattern(str)
    return str:gsub("([%^%$%(%)%%%.%[%]%*%+%-%?])", "%%%1")
end
-- Class display name mapping
local classMap = {
    DEATHKNIGHT = "Death Knight",
    DRUID = "Druid",
    HUNTER = "Hunter",
    MAGE = "Mage",
    PALADIN = "Paladin",
    PRIEST = "Priest",
    ROGUE = "Rogue",
    SHAMAN = "Shaman",
    WARLOCK = "Warlock",
    WARRIOR = "Warrior",
}
-- Class colors mapping
local classColors = {
    ["Death Knight"] = {r = 0.77, g = 0.12, b = 0.23},
    ["Druid"] = {r = 1.0, g = 0.49, b = 0.04},
    ["Hunter"] = {r = 0.67, g = 0.83, b = 0.45},
    ["Mage"] = {r = 0.41, g = 0.8, b = 0.94},
    ["Paladin"] = {r = 0.96, g = 0.55, b = 0.73},
    ["Priest"] = {r = 1.0, g = 1.0, b = 1.0},
    ["Rogue"] = {r = 1.0, g = 0.96, b = 0.41},
    ["Shaman"] = {r = 0.0, g = 0.44, b = 0.87},
    ["Warlock"] = {r = 0.58, g = 0.51, b = 0.79},
    ["Warrior"] = {r = 0.78, g = 0.61, b = 0.43},
    ["Unknown"] = {r = 1.0, g = 1.0, b = 1.0},
}
-- Function to get current streak for a opponent
local function GetCurrentStreak(name)
    local history = DuelRecordDBPC.opponents[name].history or {}
    local streak = 0
    local j = #history
    while j > 0 do
        local out = history[j].outcome
        if out == "win" or out == "opponent_fled" then
            streak = streak + 1
            j = j - 1
        else
            break
        end
    end
    return streak
end
-- Function to update the opponent list in Frame B
local opponentTexts = {}
local classTexts = {}
local winPercentTexts = {}
local winTexts = {}
local lossTexts = {}
local fledTexts = {}
local winStreakTexts = {}
local bestStreakTexts = {}
local firstDueledTexts = {}
local lastDueledTexts = {}
local rowButtons = {}
local function UpdateOpponentList()
    for _, fs in ipairs(opponentTexts) do
        fs:Hide()
    end
    for _, fs in ipairs(classTexts) do
        fs:Hide()
    end
    for _, fs in ipairs(winPercentTexts) do
        fs:Hide()
    end
    for _, fs in ipairs(winTexts) do
        fs:Hide()
    end
    for _, fs in ipairs(lossTexts) do
        fs:Hide()
    end
    for _, fs in ipairs(fledTexts) do
        fs:Hide()
    end
    for _, fs in ipairs(winStreakTexts) do
        fs:Hide()
    end
    for _, fs in ipairs(bestStreakTexts) do
        fs:Hide()
    end
    for _, fs in ipairs(firstDueledTexts) do
        fs:Hide()
    end
    for _, fs in ipairs(lastDueledTexts) do
        fs:Hide()
    end
    for _, btn in ipairs(rowButtons) do
        btn:Hide()
    end
    local names = {}
    for name in pairs(DuelRecordDBPC.opponents or {}) do
        local opp = DuelRecordDBPC.opponents[name]
        if selectedClasses[opp.class or "Unknown"] then
            table.insert(names, name)
        end
    end
    if currentSort == "name" then
        table.sort(names, function(a, b)
            if sortAscending then
                return a < b
            else
                return a > b
            end
        end)
    elseif currentSort == "class" then
        table.sort(names, function(a, b)
            local classA = DuelRecordDBPC.opponents[a].class or "Unknown"
            local classB = DuelRecordDBPC.opponents[b].class or "Unknown"
            if classA == classB then
                return a < b
            end
            if sortAscending then
                return classA < classB
            else
                return classA > classB
            end
        end)
    elseif currentSort == "win_percent" then
        table.sort(names, function(a, b)
            local dataA = DuelRecordDBPC.opponents[a]
            local winsA = dataA.wins or 0
            local lossesA = dataA.losses or 0
            local totalA = winsA + lossesA
            local percentA = totalA > 0 and (winsA / totalA) or 0
            local dataB = DuelRecordDBPC.opponents[b]
            local winsB = dataB.wins or 0
            local lossesB = dataB.losses or 0
            local totalB = winsB + lossesB
            local percentB = totalB > 0 and (winsB / totalB) or 0
            if percentA == percentB then
                return a < b
            end
            if sortAscending then
                return percentA < percentB
            else
                return percentA > percentB
            end
        end)
    elseif currentSort == "wins" then
        table.sort(names, function(a, b)
            local valA = DuelRecordDBPC.opponents[a].wins or 0
            local valB = DuelRecordDBPC.opponents[b].wins or 0
            if valA == valB then
                return a < b
            end
            if sortAscending then
                return valA < valB
            else
                return valA > valB
            end
        end)
    elseif currentSort == "losses" then
        table.sort(names, function(a, b)
            local valA = DuelRecordDBPC.opponents[a].losses or 0
            local valB = DuelRecordDBPC.opponents[b].losses or 0
            if valA == valB then
                return a < b
            end
            if sortAscending then
                return valA < valB
            else
                return valA > valB
            end
        end)
    elseif currentSort == "fled" then
        table.sort(names, function(a, b)
            local valA = DuelRecordDBPC.opponents[a].fled or 0
            local valB = DuelRecordDBPC.opponents[b].fled or 0
            if valA == valB then
                return a < b
            end
            if sortAscending then
                return valA < valB
            else
                return valA > valB
            end
        end)
    elseif currentSort == "win_streak" then
        table.sort(names, function(a, b)
            local valA = GetCurrentStreak(a)
            local valB = GetCurrentStreak(b)
            if valA == valB then
                return a < b
            end
            if sortAscending then
                return valA < valB
            else
                return valA > valB
            end
        end)
    elseif currentSort == "best_streak" then
        table.sort(names, function(a, b)
            local valA = DuelRecordDBPC.opponents[a].bestStreak or 0
            local valB = DuelRecordDBPC.opponents[b].bestStreak or 0
            if valA == valB then
                return a < b
            end
            if sortAscending then
                return valA < valB
            else
                return valA > valB
            end
        end)
    elseif currentSort == "first_dueled" then
        table.sort(names, function(a, b)
            local valA = DuelRecordDBPC.opponents[a].firstDueled or 0
            local valB = DuelRecordDBPC.opponents[b].firstDueled or 0
            if valA == valB then
                return a < b
            end
            if sortAscending then
                return valA < valB
            else
                return valA > valB
            end
        end)
    elseif currentSort == "last_dueled" then
        table.sort(names, function(a, b)
            local valA = DuelRecordDBPC.opponents[a].lastDueled or 0
            local valB = DuelRecordDBPC.opponents[b].lastDueled or 0
            if valA == valB then
                return a < b
            end
            if sortAscending then
                return valA < valB
            else
                return valA > valB
            end
        end)
    end
    for i, name in ipairs(names) do
        local button = rowButtons[i]
        if not button then
            button = CreateFrame("Button", nil, content)
            button:SetSize(content:GetWidth(), 20)
            button:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")
            table.insert(rowButtons, button)
        end
        button:SetPoint("TOPLEFT", content, "TOPLEFT", 0, -10 - (i-1)*20)
        button:Show()
        local fs = opponentTexts[i]
        if not fs then
            fs = FrameB:CreateFontString(nil, "OVERLAY", "GameFontNormal")
            fs:SetWidth(105)
            fs:SetHeight(20)
            fs:SetJustifyH("LEFT")
            fs:SetJustifyV("MIDDLE")
            table.insert(opponentTexts, fs)
        end
        fs:SetTextColor(1, 1, 1, 1) -- White text
        fs:SetText(name)
        fs:SetPoint("TOPLEFT", FrameB, "TOPLEFT", 10, -10 - (i-1)*20)
        fs:Show()
        local class = DuelRecordDBPC.opponents[name].class or "Unknown"
        local classFs = classTexts[i]
        if not classFs then
            classFs = FrameB:CreateFontString(nil, "OVERLAY", "GameFontNormal")
            classFs:SetWidth(95)
            classFs:SetHeight(20)
            classFs:SetJustifyH("LEFT")
            classFs:SetJustifyV("MIDDLE")
            table.insert(classTexts, classFs)
        end
        local color = classColors[class] or {r=1, g=1, b=1}
        classFs:SetTextColor(color.r, color.g, color.b, 1)
        classFs:SetText(class)
        classFs:SetPoint("TOPLEFT", FrameB, "TOPLEFT", 115, -10 - (i-1)*20)
        classFs:Show()
        local winsVs = DuelRecordDBPC.opponents[name].wins or 0
        local lossesVs = DuelRecordDBPC.opponents[name].losses or 0
        local totalVs = winsVs + lossesVs
        local percent = totalVs > 0 and string.format("%.2f", (winsVs / totalVs) * 100) or "0.00"
        local num_percent = totalVs > 0 and (winsVs / totalVs) * 100 or 0
        local red = math.floor(255 * (1 - num_percent / 100) + 0.5)
        local green = math.floor(255 * (num_percent / 100) + 0.5)
        local blue = 0
        local color_code = string.format("|cFF%02X%02X%02X", red, green, blue)
        local percentStr = color_code .. percent .. "%|r"
        local percentFs = winPercentTexts[i]
        if not percentFs then
            percentFs = FrameC:CreateFontString(nil, "OVERLAY", "GameFontNormal")
            percentFs:SetWidth(70)
            percentFs:SetHeight(20)
            percentFs:SetJustifyH("LEFT")
            percentFs:SetJustifyV("MIDDLE")
            table.insert(winPercentTexts, percentFs)
        end
        percentFs:SetText(percentStr)
        percentFs:SetPoint("TOPLEFT", FrameC, "TOPLEFT", 10, -10 - (i-1)*20)
        percentFs:Show()
        local winFs = winTexts[i]
        if not winFs then
            winFs = FrameC:CreateFontString(nil, "OVERLAY", "GameFontNormal")
            winFs:SetWidth(50)
            winFs:SetHeight(20)
            winFs:SetJustifyH("LEFT")
            winFs:SetJustifyV("MIDDLE")
            table.insert(winTexts, winFs)
        end
        winFs:SetTextColor(0, 1, 0, 1) -- Green text
        winFs:SetText(winsVs)
        winFs:SetPoint("TOPLEFT", FrameC, "TOPLEFT", 80, -10 - (i-1)*20)
        winFs:Show()
        local lossFs = lossTexts[i]
        if not lossFs then
            lossFs = FrameC:CreateFontString(nil, "OVERLAY", "GameFontNormal")
            lossFs:SetWidth(50)
            lossFs:SetHeight(20)
            lossFs:SetJustifyH("LEFT")
            lossFs:SetJustifyV("MIDDLE")
            table.insert(lossTexts, lossFs)
        end
        lossFs:SetTextColor(1, 0, 0, 1) -- Red text
        lossFs:SetText(lossesVs)
        lossFs:SetPoint("TOPLEFT", FrameC, "TOPLEFT", 130, -10 - (i-1)*20)
        lossFs:Show()
        local fledVs = DuelRecordDBPC.opponents[name].fled or 0
        local fledFs = fledTexts[i]
        if not fledFs then
            fledFs = FrameC:CreateFontString(nil, "OVERLAY", "GameFontNormal")
            fledFs:SetWidth(50)
            fledFs:SetHeight(20)
            fledFs:SetJustifyH("LEFT")
            fledFs:SetJustifyV("MIDDLE")
            table.insert(fledTexts, fledFs)
        end
        fledFs:SetTextColor(1, 0.8, 0, 1) -- Orange-yellow text
        fledFs:SetText(fledVs)
        fledFs:SetPoint("TOPLEFT", FrameC, "TOPLEFT", 180, -10 - (i-1)*20)
        fledFs:Show()
        local history = DuelRecordDBPC.opponents[name].history or {}
        local streak = 0
        local j = #history
        while j > 0 do
            local out = history[j].outcome
            if out == "win" or out == "opponent_fled" then
                streak = streak + 1
                j = j - 1
            else
                break
            end
        end
        local streakFs = winStreakTexts[i]
        if not streakFs then
            streakFs = FrameC:CreateFontString(nil, "OVERLAY", "GameFontNormal")
            streakFs:SetWidth(80)
            streakFs:SetHeight(20)
            streakFs:SetJustifyH("LEFT")
            streakFs:SetJustifyV("MIDDLE")
            table.insert(winStreakTexts, streakFs)
        end
        streakFs:SetTextColor(0, 1, 0, 1) -- Green text
        streakFs:SetText(streak)
        streakFs:SetPoint("TOPLEFT", FrameC, "TOPLEFT", 230, -10 - (i-1)*20)
        streakFs:Show()
        local bestStreak = DuelRecordDBPC.opponents[name].bestStreak or 0
        local bsFs = bestStreakTexts[i]
        if not bsFs then
            bsFs = FrameC:CreateFontString(nil, "OVERLAY", "GameFontNormal")
            bsFs:SetWidth(80)
            bsFs:SetHeight(20)
            bsFs:SetJustifyH("LEFT")
            bsFs:SetJustifyV("MIDDLE")
            table.insert(bestStreakTexts, bsFs)
        end
        bsFs:SetTextColor(0, 1, 0, 1) -- Green text
        bsFs:SetText(bestStreak)
        bsFs:SetPoint("TOPLEFT", FrameC, "TOPLEFT", 310, -10 - (i-1)*20)
        bsFs:Show()
        local firstDueled = DuelRecordDBPC.opponents[name].firstDueled
        local dateStr = firstDueled and date("%Y/%m/%d %H:%M", firstDueled) or "N/A"
        local fdFs = firstDueledTexts[i]
        if not fdFs then
            fdFs = FrameC:CreateFontString(nil, "OVERLAY", "GameFontNormal")
            fdFs:SetWidth(150)
            fdFs:SetHeight(20)
            fdFs:SetJustifyH("LEFT")
            fdFs:SetJustifyV("MIDDLE")
            table.insert(firstDueledTexts, fdFs)
        end
        local fdColor = {1, 1, 1, 1} -- Default white
        if #history > 0 then
            local firstOutcome = history[1].outcome
            if firstOutcome == "win" then
                fdColor = {0, 1, 0, 1} -- Green
            elseif firstOutcome == "loss" then
                fdColor = {1, 0, 0, 1} -- Red
            elseif firstOutcome == "opponent_fled" then
                fdColor = {1, 0.8, 0, 1} -- Orange-yellow
            end
        end
        fdFs:SetTextColor(unpack(fdColor))
        fdFs:SetText(dateStr)
        fdFs:SetPoint("TOPLEFT", FrameC, "TOPLEFT", 390, -10 - (i-1)*20)
        fdFs:Show()
        local lastDueled = DuelRecordDBPC.opponents[name].lastDueled
        local lastDateStr = lastDueled and date("%Y/%m/%d %H:%M", lastDueled) or "N/A"
        local ldFs = lastDueledTexts[i]
        if not ldFs then
            ldFs = FrameC:CreateFontString(nil, "OVERLAY", "GameFontNormal")
            ldFs:SetWidth(150)
            ldFs:SetHeight(20)
            ldFs:SetJustifyH("LEFT")
            ldFs:SetJustifyV("MIDDLE")
            table.insert(lastDueledTexts, ldFs)
        end
        local ldColor = {1, 1, 1, 1} -- Default white
        if #history > 0 then
            local lastOutcome = history[#history].outcome
            if lastOutcome == "win" then
                ldColor = {0, 1, 0, 1} -- Green
            elseif lastOutcome == "loss" then
                ldColor = {1, 0, 0, 1} -- Red
            elseif lastOutcome == "opponent_fled" then
                ldColor = {1, 0.8, 0, 1} -- Orange-yellow
            end
        end
        ldFs:SetTextColor(unpack(ldColor))
        ldFs:SetText(lastDateStr)
        ldFs:SetPoint("TOPLEFT", FrameC, "TOPLEFT", 540, -10 - (i-1)*20)
        ldFs:Show()
    end
    local num = #names
    local itemHeight = 20
    local contentHeight = math.max(280, num * itemHeight)
    content:SetHeight(contentHeight)
    FrameB:SetHeight(contentHeight)
    FrameC:SetHeight(contentHeight)
    scrollFrame:UpdateScrollChildRect()
end
-- Title for the "Name" column on Frame B1, above Frame B's character names
local nameButton = CreateFrame("Button", nil, FrameB1)
nameButton:SetPoint("TOPLEFT", FrameB1, "TOPLEFT", 10, -5)
nameButton:SetSize(105, 30)
local nameTitle = nameButton:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
nameTitle:SetPoint("TOPLEFT", nameButton, "TOPLEFT", 0, -10)
nameTitle:SetText("Name")
nameTitle:SetWidth(105)
nameTitle:SetJustifyH("LEFT")
nameButton:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")
nameButton:SetScript("OnClick", function(self)
    currentSort = "name"
    sortAscending = not sortAscending
    UpdateOpponentList()
end)
-- Title for the "Class" column on Frame B1, above Frame B's class list
local classButton = CreateFrame("Button", nil, FrameB1)
classButton:SetPoint("TOPLEFT", FrameB1, "TOPLEFT", 115, -5)
classButton:SetSize(95, 30)
local classTitle = classButton:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
classTitle:SetPoint("TOPLEFT", classButton, "TOPLEFT", 0, -10)
classTitle:SetText("Class")
classTitle:SetWidth(95)
classTitle:SetJustifyH("LEFT")
classButton:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")
classButton:SetScript("OnClick", function(self)
    currentSort = "class"
    sortAscending = not sortAscending
    UpdateOpponentList()
end)
-- Title for the "Win %" column on Frame C1
local winPercentButton = CreateFrame("Button", nil, FrameC1)
winPercentButton:SetPoint("TOPLEFT", FrameC1, "TOPLEFT", 10, -5)
winPercentButton:SetSize(70, 30)
local winPercentTitle = winPercentButton:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
winPercentTitle:SetPoint("TOPLEFT", winPercentButton, "TOPLEFT", 0, -10)
winPercentTitle:SetText("Win %")
winPercentTitle:SetWidth(70)
winPercentTitle:SetJustifyH("LEFT")
winPercentButton:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")
winPercentButton:SetScript("OnClick", function(self)
    currentSort = "win_percent"
    sortAscending = not sortAscending
    UpdateOpponentList()
end)
-- Title for the "Wins" column on Frame C1
local winsButton = CreateFrame("Button", nil, FrameC1)
winsButton:SetPoint("TOPLEFT", FrameC1, "TOPLEFT", 80, -5)
winsButton:SetSize(50, 30)
local winsTitle = winsButton:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
winsTitle:SetPoint("TOPLEFT", winsButton, "TOPLEFT", 0, -10)
winsTitle:SetText("Wins")
winsTitle:SetWidth(50)
winsTitle:SetJustifyH("LEFT")
winsButton:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")
winsButton:SetScript("OnClick", function(self)
    currentSort = "wins"
    sortAscending = not sortAscending
    UpdateOpponentList()
end)
-- Title for the "Losses" column on Frame C1
local lossesButton = CreateFrame("Button", nil, FrameC1)
lossesButton:SetPoint("TOPLEFT", FrameC1, "TOPLEFT", 130, -5)
lossesButton:SetSize(50, 30)
local lossesTitle = lossesButton:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
lossesTitle:SetPoint("TOPLEFT", lossesButton, "TOPLEFT", 0, -10)
lossesTitle:SetText("Losses")
lossesTitle:SetWidth(50)
lossesTitle:SetJustifyH("LEFT")
lossesButton:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")
lossesButton:SetScript("OnClick", function(self)
    currentSort = "losses"
    sortAscending = not sortAscending
    UpdateOpponentList()
end)
-- Title for the "Fled" column on Frame C1
local fledButton = CreateFrame("Button", nil, FrameC1)
fledButton:SetPoint("TOPLEFT", FrameC1, "TOPLEFT", 180, -5)
fledButton:SetSize(50, 30)
local fledTitle = fledButton:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
fledTitle:SetPoint("TOPLEFT", fledButton, "TOPLEFT", 0, -10)
fledTitle:SetText("Fled")
fledTitle:SetWidth(50)
fledTitle:SetJustifyH("LEFT")
fledButton:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")
fledButton:SetScript("OnClick", function(self)
    currentSort = "fled"
    sortAscending = not sortAscending
    UpdateOpponentList()
end)
-- Title for the "Win Streak" column on Frame C1
local winStreakButton = CreateFrame("Button", nil, FrameC1)
winStreakButton:SetPoint("TOPLEFT", FrameC1, "TOPLEFT", 230, -5)
winStreakButton:SetSize(80, 30)
local winStreakTitle = winStreakButton:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
winStreakTitle:SetPoint("TOPLEFT", winStreakButton, "TOPLEFT", 0, -10)
winStreakTitle:SetText("Win Streak")
winStreakTitle:SetWidth(80)
winStreakTitle:SetJustifyH("LEFT")
winStreakButton:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")
winStreakButton:SetScript("OnClick", function(self)
    currentSort = "win_streak"
    sortAscending = not sortAscending
    UpdateOpponentList()
end)
-- Title for the "Best Streak" column on Frame C1
local bestStreakButton = CreateFrame("Button", nil, FrameC1)
bestStreakButton:SetPoint("TOPLEFT", FrameC1, "TOPLEFT", 310, -5)
bestStreakButton:SetSize(80, 30)
local bestStreakTitle = bestStreakButton:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
bestStreakTitle:SetPoint("TOPLEFT", bestStreakButton, "TOPLEFT", 0, -10)
bestStreakTitle:SetText("Best Streak")
bestStreakTitle:SetWidth(80)
bestStreakTitle:SetJustifyH("LEFT")
bestStreakButton:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")
bestStreakButton:SetScript("OnClick", function(self)
    currentSort = "best_streak"
    sortAscending = not sortAscending
    UpdateOpponentList()
end)
-- Title for the "First Dueled" column on Frame C1
local firstDueledButton = CreateFrame("Button", nil, FrameC1)
firstDueledButton:SetPoint("TOPLEFT", FrameC1, "TOPLEFT", 390, -5)
firstDueledButton:SetSize(150, 30)
local firstDueledTitle = firstDueledButton:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
firstDueledTitle:SetPoint("TOPLEFT", firstDueledButton, "TOPLEFT", 0, -10)
firstDueledTitle:SetText("First Dueled")
firstDueledTitle:SetWidth(150)
firstDueledTitle:SetJustifyH("LEFT")
firstDueledButton:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")
firstDueledButton:SetScript("OnClick", function(self)
    currentSort = "first_dueled"
    sortAscending = not sortAscending
    UpdateOpponentList()
end)
-- Title for the "Last Dueled" column on Frame C1
local lastDueledButton = CreateFrame("Button", nil, FrameC1)
lastDueledButton:SetPoint("TOPLEFT", FrameC1, "TOPLEFT", 540, -5)
lastDueledButton:SetSize(150, 30)
local lastDueledTitle = lastDueledButton:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
lastDueledTitle:SetPoint("TOPLEFT", lastDueledButton, "TOPLEFT", 0, -10)
lastDueledTitle:SetText("Last Dueled")
lastDueledTitle:SetWidth(150)
lastDueledTitle:SetJustifyH("LEFT")
lastDueledButton:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")
lastDueledButton:SetScript("OnClick", function(self)
    currentSort = "last_dueled"
    sortAscending = not sortAscending
    UpdateOpponentList()
end)
-- Create the filter frame for multi-select classes
local filterFrame = CreateFrame("Frame", "DuelRecordFilterFrame", FrameA)
filterFrame:SetSize(135, 350)
filterFrame:SetPoint("TOPRIGHT", FrameA, "TOPRIGHT", -25, -50)
filterFrame:SetBackdrop({
    bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 16,
})
filterFrame:SetBackdropColor(0, 0, 0, 0.8)
filterFrame:Show()
-- Add "Stat Filter" text on top of the class filter menu
local statFilterText = filterFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
statFilterText:SetPoint("BOTTOM", filterFrame, "TOP", 0, 0)
statFilterText:SetTextColor(1, 1, 1, 1) -- White text
statFilterText:SetText("Stat Filter")
-- Checkboxes for classes
local checkboxes = {}
for i, class in ipairs(classes) do
    local cb = CreateFrame("CheckButton", "DuelRecordClassCheckbox" .. i, filterFrame, "UICheckButtonTemplate")
    cb:SetPoint("TOPLEFT", 10, -10 - (i-1)*25)
    local text = _G[cb:GetName() .. "Text"]
    text:SetText(class)
    cb:SetChecked(selectedClasses[class])
    cb:SetScript("OnClick", function(self)
        selectedClasses[class] = self:GetChecked()
        UpdateRecordText()
        UpdateCurrentStreakText()
        UpdateBestStreakText()
        UpdateOpponentList()
    end)
    checkboxes[class] = cb
end
-- Deselect All button
local deselectAll = CreateFrame("Button", nil, filterFrame, "UIPanelButtonTemplate")
deselectAll:SetSize(80, 22)
deselectAll:SetPoint("BOTTOMLEFT", 10, 40)
deselectAll:SetText("Deselect All")
deselectAll:SetScript("OnClick", function()
    for _, class in ipairs(classes) do
        selectedClasses[class] = false
        checkboxes[class]:SetChecked(false)
    end
    UpdateRecordText()
    UpdateCurrentStreakText()
    UpdateBestStreakText()
    UpdateOpponentList()
end)
-- Select All button
local selectAll = CreateFrame("Button", nil, filterFrame, "UIPanelButtonTemplate")
selectAll:SetSize(80, 22)
selectAll:SetPoint("BOTTOMLEFT", 10, 10)
selectAll:SetText("Select All")
selectAll:SetScript("OnClick", function()
    for _, class in ipairs(classes) do
        selectedClasses[class] = true
        checkboxes[class]:SetChecked(true)
    end
    UpdateRecordText()
    UpdateCurrentStreakText()
    UpdateBestStreakText()
    UpdateOpponentList()
end)
-- Add purple text "Creator- Ingurgitate" in the bottom right corner of Frame A
local creatorText = FrameA:CreateFontString(nil, "OVERLAY", "GameFontNormal")
creatorText:SetPoint("BOTTOMRIGHT", FrameA, "BOTTOMRIGHT", -10, 10)
creatorText:SetTextColor(0.5, 0, 1, 0.5) -- Purple, 50% translucent
creatorText:SetText("Creator- Ingurgitate")
-- Event frame for handling addon loaded and chat messages
local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("ADDON_LOADED")
eventFrame:RegisterEvent("CHAT_MSG_SYSTEM")
eventFrame:SetScript("OnEvent", function(self, event, ...)
    if event == "ADDON_LOADED" and ... == "DuelRecord" then
        if not DuelRecordDBPC then
            DuelRecordDBPC = {
                wins = 0,
                losses = 0,
                opponents = {},
            }
        end
        for _, opp in pairs(DuelRecordDBPC.opponents) do
            if not opp.history then
                opp.history = {}
            end
            if not opp.bestStreak then
                opp.bestStreak = 0
            end
            local currentStreak = 0
            for _, record in ipairs(opp.history) do
                if record.outcome == "win" or record.outcome == "opponent_fled" then
                    currentStreak = currentStreak + 1
                    opp.bestStreak = math.max(opp.bestStreak, currentStreak)
                else
                    currentStreak = 0
                end
            end
        end
        DuelRecordDBPC.currentStreak = DuelRecordDBPC.currentStreak or 0
        DuelRecordDBPC.bestOverallStreak = DuelRecordDBPC.bestOverallStreak or 0
        UpdateRecordText()
        UpdateCurrentStreakText()
        UpdateBestStreakText()
        UpdateOpponentList()
    elseif event == "CHAT_MSG_SYSTEM" then
        local msg = ...
        local playerName = UnitName("player")
        local playerNameEsc = escapePattern(playerName)
        local winPattern = playerNameEsc .. " has defeated (.+) in a duel"
        local lossPattern = "(.+) has defeated " .. playerNameEsc .. " in a duel"
        local fleeByOpponentPattern = "(.+) has fled from " .. playerNameEsc .. " in a duel"
        local fleeByPlayerPattern = "You have fled from (.+) in a duel"
        local isWin = false
        local isFleeByOpponent = false
        local isFleeByPlayer = false
        local opponent = msg:match(winPattern)
        if opponent then
            isWin = true
        else
            opponent = msg:match(lossPattern)
            if opponent then
                -- isWin remains false
            else
                opponent = msg:match(fleeByOpponentPattern)
                if opponent then
                    isFleeByOpponent = true
                else
                    opponent = msg:match(fleeByPlayerPattern)
                    if opponent then
                        isFleeByPlayer = true
                    end
                end
            end
        end
        if opponent then
            if not DuelRecordDBPC.opponents[opponent] then
                DuelRecordDBPC.opponents[opponent] = {wins = 0, losses = 0, fled = 0, firstDueled = time(), history = {}, bestStreak = 0}
            end
            local targetName = UnitName("target")
            if targetName == opponent and not DuelRecordDBPC.opponents[opponent].class then
                local _, englishClass = UnitClass("target")
                DuelRecordDBPC.opponents[opponent].class = classMap[englishClass] or englishClass
            end
            local currentTime = time()
            local outcome
            local currentStreak = 0
            if #DuelRecordDBPC.opponents[opponent].history > 0 then
                local j = #DuelRecordDBPC.opponents[opponent].history
                while j > 0 do
                    local out = DuelRecordDBPC.opponents[opponent].history[j].outcome
                    if out == "win" or out == "opponent_fled" then
                        currentStreak = currentStreak + 1
                        j = j - 1
                    else
                        break
                    end
                end
            end
            if isWin or isFleeByOpponent then
                currentStreak = currentStreak + 1
                DuelRecordDBPC.opponents[opponent].bestStreak = math.max(DuelRecordDBPC.opponents[opponent].bestStreak, currentStreak)
                DuelRecordDBPC.currentStreak = DuelRecordDBPC.currentStreak + 1
                DuelRecordDBPC.bestOverallStreak = math.max(DuelRecordDBPC.bestOverallStreak, DuelRecordDBPC.currentStreak)
            else
                currentStreak = 0
                DuelRecordDBPC.currentStreak = 0
            end
            if isWin then
                DuelRecordDBPC.opponents[opponent].wins = DuelRecordDBPC.opponents[opponent].wins + 1
                DuelRecordDBPC.wins = DuelRecordDBPC.wins + 1
                outcome = "win"
            elseif isFleeByOpponent then
                DuelRecordDBPC.opponents[opponent].fled = DuelRecordDBPC.opponents[opponent].fled + 1
                outcome = "opponent_fled"
            elseif isFleeByPlayer then
                DuelRecordDBPC.opponents[opponent].losses = DuelRecordDBPC.opponents[opponent].losses + 1
                DuelRecordDBPC.losses = DuelRecordDBPC.losses + 1
                outcome = "loss"
            else
                DuelRecordDBPC.opponents[opponent].losses = DuelRecordDBPC.opponents[opponent].losses + 1
                DuelRecordDBPC.losses = DuelRecordDBPC.losses + 1
                outcome = "loss"
            end
            table.insert(DuelRecordDBPC.opponents[opponent].history, {time = currentTime, outcome = outcome})
            DuelRecordDBPC.opponents[opponent].lastDueled = currentTime
            UpdateRecordText()
            UpdateCurrentStreakText()
            UpdateBestStreakText()
            UpdateOpponentList()
            local winsVs = DuelRecordDBPC.opponents[opponent].wins or 0
            local lossesVs = DuelRecordDBPC.opponents[opponent].losses or 0
            local firstDateStr = date("%Y/%m/%d %H:%M", DuelRecordDBPC.opponents[opponent].firstDueled)
            local emoteMessage = "vs " .. opponent .. " '" .. winsVs .. " - " .. lossesVs .. "', record began " .. firstDateStr
            SendChatMessage(emoteMessage, "EMOTE")
            if (isWin or isFleeByOpponent) and specialStreaks[currentStreak] then
                SendChatMessage("has defeated " .. opponent .. " ***" .. currentStreak .. "*** times in a row!", "EMOTE")
            end
            if (isWin or isFleeByOpponent) and specialStreaks[DuelRecordDBPC.currentStreak] then
                SendChatMessage("has won ***" .. DuelRecordDBPC.currentStreak .. "*** duels in a row!", "EMOTE")
            end
        end
    end
end)
-- Register the slash command to toggle the frame
SlashCmdList["DUELRECORD"] = function(msg)
    if FrameA:IsShown() then
        FrameA:Hide()
    else
        FrameA:Show()
        UpdateOpponentList()
    end
end
SLASH_DUELRECORD1 = "/duelrecord"